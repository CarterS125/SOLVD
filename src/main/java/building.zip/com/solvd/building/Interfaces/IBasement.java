package com.solvd.building.Interfaces;

import java.util.HashMap;
import java.util.Map;

public interface IBasement {
    static void build() {
        HashMap<Integer,String> basement =new HashMap<Integer,String>();
        basement.put(1,"build a basement");
        basement.put(2,"build parking garage in basement ");

        System.out.println("Iterating Hashmap...");
        for(Map.Entry m : basement.entrySet()){
            System.out.println(m.getKey()+" "+m.getValue());
        }
        IBasement.build();
    }
    void overrideMethod(String str);
}


