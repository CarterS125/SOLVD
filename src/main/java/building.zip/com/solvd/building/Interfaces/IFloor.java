package com.solvd.building.Interfaces;

import java.util.HashMap;
import java.util.Map;

public interface IFloor {
    static void build() {
        HashMap<Integer, String> floor = new HashMap<Integer, String>();
        floor.put(1, "lobby");
        floor.put(2, "conference and meeting halls");
        floor.put(3, "normal apartment floor 1");
        floor.put(4, "normal apartments floor 2");
        floor.put(5, "normal apartments floor 3");
        floor.put(6, "normal apartments floor 4");
        floor.put(7, "normal apartments floor 5");
        floor.put(8, "luxury apartments floor 1");
        floor.put(9, "luxury apartments floor 2");
        floor.put(10, "luxury apartments floor 3");
        floor.put(11, "penthouse floor");

        System.out.println("Iterating Hashmap...");
        for (Map.Entry m : floor.entrySet()) {
            System.out.println(m.getKey() + " " + m.getValue());
        }
        IFloor.build();
    }
    void overrideMethod(String str);
}

