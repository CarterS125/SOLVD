package com.solvd.building.Interfaces;

import java.util.HashMap;
import java.util.Map;

public interface IWall {
    static void build() {
        HashMap<Integer, String> wall = new HashMap<Integer, String>();
        wall.put(1, "front of building");
        wall.put(2, "left side of building");
        wall.put(3, "right side of building");
        wall.put(4, "back side of building");

        System.out.println("Iterating Hashmap...");
        for (Map.Entry m : wall.entrySet()) {
            System.out.println(m.getKey() + " " + m.getValue());
        }
        IWall.build();
    }

    void overrideMethod(String str);
}
