package com.solvd.building.Interfaces;

import java.util.HashMap;
import java.util.Map;

public interface IRoom {
    static void build() {
        HashMap<Integer, String> room = new HashMap<Integer, String>();
        room.put(1, "Build a lobby room and leasing office room");
        room.put(2, "Build conference rooms and meetings hall rooms/floor 1");
        room.put(3, "Build 10 rooms per floor for normal apartments/floor 2");
        room.put(4, "Build 10 rooms per floor for normal apartments/floor 3");
        room.put(5, "Build 10 rooms per floor for normal apartments/floor 4");
        room.put(6, "Build 10 rooms per floor for normal apartments/floor 5");
        room.put(7, "Build 10 rooms per floor for normal apartments/floor 6");
        room.put(8, "Build 10 rooms per floor for luxury apartments/floor 7");
        room.put(9, "Build 10 rooms per floor for luxury apartments/floor 8");
        room.put(10, "Build 10 rooms per floor for luxury apartments/floor 9");
        room.put(11, "Build 10 rooms per floor for penthouse suites/floor 10");

        System.out.println("Iterating Hashmap...");
        for (Map.Entry m : room.entrySet()) {
            System.out.println(m.getKey() + " " + m.getValue());
        }
        IRoom.build();
    }

    void overrideMethod(String str);
}
