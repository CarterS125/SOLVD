package com.solvd.building.Interfaces;

import java.util.HashMap;
import java.util.Map;

public interface IRoof {
    static void build() {
        HashMap<Integer, String> floor = new HashMap<Integer, String>();
        floor.put(1, "build a roof that is modern ");
        floor.put(2, "build the roof to incorporate a viewing spot where residents can go to and enjoy the view");

        System.out.println("Iterating Hashmap...");
        for (Map.Entry m : floor.entrySet()) {
            System.out.println(m.getKey() + " " + m.getValue());
        }
        IRoof.build();
    }

    void overrideMethod(String str);
}
