package com.solvd.building.BuildingStaff;

import com.solvd.building.BuildingTools.PaintBrush_PaintRoller;
import com.solvd.building.Materials.Paint;
import com.solvd.building.building.Builder;

public class Painter extends Builder {
    private String fName;
    private String lName;
    private String companyName;
    private int price;
    private Paint paint;
    private PaintBrush_PaintRoller paintBrush_paintRoller;

    public Painter() {}

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getlName() {
        return lName;
    }

    public void setlName(String lName) {
        this.lName = lName;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public Paint getPaint() {
        return paint;
    }

    public void setPaint(Paint paint) {
        this.paint = paint;
    }

    public PaintBrush_PaintRoller getPaintBrush_paintRoller() {
        return paintBrush_paintRoller;
    }

    public void setPaintBrush_paintRoller(PaintBrush_PaintRoller paintBrush_paintRoller) {
        this.paintBrush_paintRoller = paintBrush_paintRoller;
    }

    public Painter (String fName, String lName, String companyName, int price, Paint paint, PaintBrush_PaintRoller paintBrush_paintRoller) {
        this.companyName = companyName;
        this.fName = fName;
        this.lName = lName;
        this.price = price;
        this.paint = paint;
        this.paintBrush_paintRoller = paintBrush_paintRoller;
    }
}
