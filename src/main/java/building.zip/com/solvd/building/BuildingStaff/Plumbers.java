package com.solvd.building.BuildingStaff;

import com.solvd.building.BuildingTools.PipeCutter;
import com.solvd.building.Materials.Piping;
import com.solvd.building.building.Builder;

public class Plumbers extends Builder {
    private String fName;
    private String lName;
    private int price;
    private String companyName;
    private Piping piping;
    private PipeCutter pipeCutter;

    public Plumbers () {}

    public Plumbers (String fName, String lName, String companyName, int price, PipeCutter pipeCutter, Piping piping) {
        this.companyName = companyName;
        this.fName = fName;
        this.lName = lName;
        this.price = price;
    }

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getlName() {
        return lName;
    }

    public void setlName(String lName) {
        this.lName = lName;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public Piping getPiping() {
        return piping;
    }

    public void setPiping(Piping piping) {
        this.piping = piping;
    }

    public PipeCutter getPipeCutter() {
        return pipeCutter;
    }

    public void setPipeCutter(PipeCutter pipeCutter) {
        this.pipeCutter = pipeCutter;
    }
}
