package com.solvd.building.BuildingStaff;

import com.solvd.building.BuildingTools.WireCutter;
import com.solvd.building.Materials.Wiring;
import com.solvd.building.building.Builder;

public class Electrician extends Builder {
    private String fName;
    private String lName;
    private String companyName;
    private int price;
    private Wiring wiring;
    private WireCutter wireCutter;


    public Electrician () {}

    public Electrician (String fName, String lName, String companyName, int price, Wiring wiring, WireCutter wireCutter) {
        this.companyName = companyName;
        this.fName = fName;
        this.lName = lName;
        this.price = price;
        this.wireCutter = wireCutter;
        this.wiring = wiring;
    }

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getlName() {
        return lName;
    }

    public void setlName(String lName) {
        this.lName = lName;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public Wiring getWiring() {
        return wiring;
    }

    public void setWiring(Wiring wiring) {
        this.wiring = wiring;
    }

    public WireCutter getWireCutter() {
        return wireCutter;
    }

    public void setWireCutter(WireCutter wireCutter) {
        this.wireCutter = wireCutter;
    }
}
