package com.solvd.building.BuildingStaff;

import com.solvd.building.BuildingTools.TrimNailGuns;
import com.solvd.building.Materials.Trim;
import com.solvd.building.building.Builder;

public class TrimGuys extends Builder {
    private String fName;
    private String lName;
    private String companyName;
    private int price;
    private TrimNailGuns trimNailGuns;
    private Trim trim;

    public TrimGuys() {}

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getlName() {
        return lName;
    }

    public void setlName(String lName) {
        this.lName = lName;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public TrimGuys (String fName, String lName, String companyName, int price, Trim trim, TrimNailGuns trimNailGuns) {
        this.companyName = companyName;
        this.fName = fName;
        this.lName = lName;
        this.price = price;
        this.trimNailGuns = trimNailGuns;
        this.trim = trim;
    }
}
