package com.solvd.building.BuildingStaff;

import com.solvd.building.BuildingTools.CabinetDrill;
import com.solvd.building.Materials.Cabinets;
import com.solvd.building.building.Builder;

public class CabinetGuys extends Builder {
    private String fName;
    private String lName;
    private String companyName;
    private int price;
    private CabinetDrill cabinetDrill;
    private Cabinets cabinets;

    public CabinetGuys (String fName, String lName, String companyName, int price, Cabinets cabinets, CabinetDrill cabinetDrill) {
        this.companyName = companyName;
        this.fName = fName;
        this.lName = lName;
        this.price = price;
        this.cabinetDrill = cabinetDrill;
        this.cabinets = cabinets;
    }

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getlName() {
        return lName;
    }

    public void setlName(String lName) {
        this.lName = lName;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public CabinetDrill getCabinetDrill() {
        return cabinetDrill;
    }

    public void setCabinetDrill(CabinetDrill cabinetDrill) {
        this.cabinetDrill = cabinetDrill;
    }

    public Cabinets getCabinets() {
        return cabinets;
    }

    public void setCabinets(Cabinets cabinets) {
        this.cabinets = cabinets;
    }
}
