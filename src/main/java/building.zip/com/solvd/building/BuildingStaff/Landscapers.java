package com.solvd.building.BuildingStaff;

import com.solvd.building.BuildingTools.PlantingTool;
import com.solvd.building.Materials.GrassAndPlants;
import com.solvd.building.building.Builder;

public class Landscapers extends Builder {
    private String fName;
    private String lName;
    private String companyName;
    private int price;
    private GrassAndPlants grassAndPlants;
    private PlantingTool plantingTool;

    public Landscapers() {}

    public Landscapers (String fName, String lName, String companyName, int price, GrassAndPlants grassAndPlants, PlantingTool plantingTool) {
        this.companyName = companyName;
        this.fName = fName;
        this.lName = lName;
        this.price = price;
        this.grassAndPlants = grassAndPlants;
        this.plantingTool = plantingTool;
    }

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getlName() {
        return lName;
    }

    public void setlName(String lName) {
        this.lName = lName;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public GrassAndPlants getGrassAndPlants() {
        return grassAndPlants;
    }

    public void setGrassAndPlants(GrassAndPlants grassAndPlants) {
        this.grassAndPlants = grassAndPlants;
    }

    public PlantingTool getPlantingTool() {
        return plantingTool;
    }

    public void setPlantingTool(PlantingTool plantingTool) {
        this.plantingTool = plantingTool;
    }
}
