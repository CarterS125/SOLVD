package com.solvd.building.BuildingStaff;

import com.solvd.building.BuildingTools.ConcretePumps;
import com.solvd.building.Materials.Concrete;
import com.solvd.building.building.Builder;

public class ConcreteGuys extends Builder {
    private String fName;
    private String lName;
    private String companyName;
    private int price;
    private Concrete concrete;
    private ConcretePumps concretePumps;

    public ConcreteGuys(String fName, String lName, String companyName, int price, Concrete concrete, ConcretePumps concretePumps) {
        this.companyName = companyName;
        this.fName = fName;
        this.lName = lName;
        this.price = price;
        this.concrete = concrete;
        this.concretePumps = concretePumps;
    }

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getlName() {
        return lName;
    }

    public void setlName(String lName) {
        this.lName = lName;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public Concrete getConcrete() {
        return concrete;
    }

    public void setConcrete(Concrete concrete) {
        this.concrete = concrete;
    }

    public ConcretePumps getConcretePumps() {
        return concretePumps;
    }

    public void setConcretePumps(ConcretePumps concretePumps) {
        this.concretePumps = concretePumps;
    }
}