package com.solvd.building.BuildingStaff;

import com.solvd.building.BuildingTools.DrywallDrill;
import com.solvd.building.Materials.Drywall;
import com.solvd.building.building.Builder;

public class DryWaller extends Builder {
    private String fName;
    private String lName;
    private String companyName;
    private int price;
    private Drywall drywall;
    private DrywallDrill drywallDrill;

    public DryWaller() {}

    public DryWaller (String fName, String lName, String companyName, int price, DrywallDrill drywallDrill, Drywall drywall) {
        this.companyName = companyName;
        this.fName = fName;
        this.lName = lName;
        this.price = price;
        this.drywall = drywall;
        this.drywallDrill = drywallDrill;
    }

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getlName() {
        return lName;
    }

    public void setlName(String lName) {
        this.lName = lName;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public Drywall getDrywall() {
        return drywall;
    }

    public void setDrywall(Drywall drywall) {
        this.drywall = drywall;
    }

    public DrywallDrill getDrywallDrill() {
        return drywallDrill;
    }

    public void setDrywallDrill(DrywallDrill drywallDrill) {
        this.drywallDrill = drywallDrill;
    }
}
