package com.solvd.building.building;

import com.solvd.building.Interfaces.IBasement;
import java.util.Arrays;
import java.util.Scanner;
import java.util.logging.Logger;

public class Basement implements IBasement {

    private String basement;

    public Basement(String[] args) throws Exception {
        Logger logger = Logger.getLogger(Basement.class.getName());
        String[] basement =  new String[4];
        basement[0] = "build a basement that incorporates a parking garage";

        System.out.println("Elements in the array are: ");
        System.out.println(Arrays.toString(basement));
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the index of the required element :");
        try {
            int element = sc.nextInt();
            System.out.println("Element in the given index is : " + basement[element]);
        } catch (ArrayIndexOutOfBoundsException e) {
            logger.info("The index you have entered is invalid");
            logger.info("Please enter an index number between 0 and 4");
        }
    }

    public Basement(){}

    public void Basement(String basement) {
        this.basement = basement;
    }

    public String getBasement() {
        return basement;
    }
    public void setBasement(String basement) {
        this.basement = basement;
    }

    @Override
    public void overrideMethod(String str) {

    }
}
