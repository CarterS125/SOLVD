package com.solvd.building.building;

import com.solvd.building.BuildingTools.*;

public class BuildingTools {
    private String tools;

    public BuildingTools(String tools) {
        this.tools = tools;
    }

    public BuildingTools() {
    }

    public String getTools() {
        return tools;
    }

    public void setTools(String tools) {
        this.tools = tools;
    }
}
