package com.solvd.building.building;

import java.util.Objects;

public class Runner {
    public static void main(String[] args) {
        Building palisades = new Building() {
            private Object building;

            @Override
            public int Hashcode() {
                return Objects.hash(building);
            }
        };
        palisades.setName("palisades");

        BuildingResident buildingResident = new BuildingResident();
        ParkingSpace parkingSpace = new ParkingSpace();
        Wall wall = new Wall();
        Roof roof = new Roof();
        Floor floor = new Floor();
        BuildingPlan buildingPlan = new BuildingPlan();
        Basement basement = new Basement();
        BuildingCapacity buildingCapacity = new BuildingCapacity();
        BuildingRentPrice buildingRentPrice = new BuildingRentPrice();
        BuildingMaterial buildingMaterial = new BuildingMaterial();
        BuildingTools buildingTools = new BuildingTools();
        BuildPrice buildPrice = new BuildPrice();
        Room rooms = new Room();
        BuildingLocation buildingLocation = new BuildingLocation();
        Builder builder = new Builder();


        buildingResident.setFName("First Name");
        buildingResident.setLName("Last Name");
        buildingResident.setAge(21);
        buildingResident.setGender("Male");
        buildingResident.setOccupation("There job for proof of income");

        wall.setWall(4);
        roof.setRoof("build a modern roof but prevents damage");
        floor.setFloor(10);
        rooms.setRoom(100);
        buildingCapacity.setCapacity(200);
        basement.setBasement("have the basement also incorporate a parking garage");
        parkingSpace.setParkingSpace(200);

        buildingPlan.setArchitecture("hire an engineer to design the building style and room design");
        buildingPlan.setColor("white, black, grey");
        buildingPlan.setSquareFeet(125000);

        buildingRentPrice.setLuxuryRent(3500);
        buildingRentPrice.setPentHouseRent(5000);
        buildingRentPrice.setNormalRent(2000);

        buildPrice.setPrice(25000000);
        buildPrice.setFinalPrice(23000000);

        buildingLocation.setCity("miami");
        buildingLocation.setState("Florida");
        buildingLocation.setCounty("Miami-Dade");
        buildingLocation.setNearOcean("yes,near ocean");

        buildingMaterial.setMaterials("use all materials in materials classes");
        buildingTools.setTools("use all tools in tools classes");
        builder.setBuild("use all builders in builderStaff to construct the building");


        Building building = palisades.building(new Building() {

            private Object Building;

            @Override
            public int Hashcode() {
                return Objects.hash(Building);
            }
        });
    }
}
