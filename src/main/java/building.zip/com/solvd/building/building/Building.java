package com.solvd.building.building;

import java.util.Iterator;
import java.util.LinkedList;
    public abstract class Building<E> {
        private String building;
        private Node head = null;
        private class Node {
            E value;
            Node next;
            Node(E value) {
                this.value = value;
                this.next = head;
            }
        }
        public void add(E e) {
            new Node(e);
        }
        public static void main(String[] args) {
            LinkedList<String> list = new LinkedList<String>();
            list.add("floor");
            list.add("roof");
            list.add("room");
            list.add("basement");
            list.add("wall");

        }
    public Building() {
    }

    public Building(String building) {
        this.building = building;
    }

    public String getBuilding() {
        return building;
    }

    public void setBuilding(String building) {
        this.building = building;
    }

    public void setName(String palisades) {
    }

    public Building building(Building building) {
        return building;
    }

    public abstract int Hashcode();
}