package com.solvd.building.building;

public class BuildingMaterial {
    private String materials;


    public BuildingMaterial() {
        this.materials = materials;
    }

    public String getMaterials() {
        return materials;
    }

    public void setMaterials(String materials) {
        this.materials = materials;
    }
}