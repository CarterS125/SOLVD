package com.solvd.building.building;

import com.solvd.building.Interfaces.IRoom;

import java.util.Arrays;
import java.util.Scanner;
import java.util.logging.Logger;

public class Room implements IRoom {

public Room(String[] args) throws Exception{
    Logger logger = Logger.getLogger(Room.class.getName());
    String[] room = new String[10];
    room[0] = "Build a lobby room and leasing office room";
    room[1] = "Build conference rooms and meetings hall rooms/floor 1";
    room[2] = "Build 10 rooms per floor for normal apartments/floor 2";
    room[3] = "Build 10 rooms per floor for normal apartments/floor 3";
    room[4] = "Build 10 rooms per floor for normal apartments/floor 4";
    room[5] = "Build 10 rooms per floor for normal apartments/floor 5";
    room[6] = "Build 10 rooms per floor for normal apartments/floor 6";
    room[7] = "Build 10 rooms per floor for luxury apartments/floor 7";
    room[8] = "Build 10 rooms per floor for luxury apartments/floor 8";
    room[9] = "Build 10 rooms per floor for luxury apartments/floor 9";
    room[10] = "Build 10 rooms per floor for penthouse suites/floor 10";

    System.out.println("Elements in the array are: ");
    System.out.println(Arrays.toString(room));
    Scanner sc = new Scanner(System.in);
    System.out.println("Enter the index of the required element :");
    try {
        int element = sc.nextInt();
        System.out.println("Element in the given index is : " + room[element]);
    } catch (ArrayIndexOutOfBoundsException e) {
        logger.info("The index you have entered is invalid");
        logger.info("Please enter an index number between 0 and 4");
    }
}
    private int room = 100;
    private Room amount;

    public Room(){}

    public void Room(int room) {
        this.room = room;
    }

    public int getRoom() {
        return room;
    }

    public void setAmount(Room amount) {
        this.amount = amount;
    }

    @Override
    public String toString() {
        return "Rooms{" +
                "rooms=" + room +
                '}';
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public boolean equals(Object o) {
        if (o == null) return false;
        if (o == this) return true;
        if (!(o instanceof Room)) {
            return false;
        }
        Room room = (Room) o;
        return room == room.amount;
    }

    public void setRoom(int i) {
    }

    @Override
    public void overrideMethod(String str) {

    }
}
