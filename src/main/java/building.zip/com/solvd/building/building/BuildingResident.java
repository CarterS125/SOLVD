package com.solvd.building.building;

public class BuildingResident {
    private String fName;
    private String lName;
    private int age;
    private String gender;
    private String occupation;

    public BuildingResident(String fName, String lName, int age, String gender, String occupation) {
        this.lName = lName;
        this.fName = fName;
        this.gender = gender;
        this.age = age;
        this.occupation = occupation;
    }

    public BuildingResident() {

    }

    public static void setResidents() {
    }

    public String getFName() {
        return fName;
    }

    public String getLName() {
        return lName;
    }

    public void setLName(String lName) {
        this.lName = lName;

    }

    public void setFName(String fName) {
        this.fName = fName;

    }


    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        gender = gender;
    }

    public String getOccupation() {
        return occupation;
    }

    public void setOccupation(String occupation) {
        occupation = occupation;
    }

}
