package com.solvd.building.building;

import com.solvd.building.BuildingStaff.*;

public class Builder {
    private String build;

    public Builder(){}

    public void Builder(String build) {
        this.build = build;
    }

    public String getBuild() {
        return build;
    }

    public void setBuild(String build) {
        this.build = build;
    }
}
