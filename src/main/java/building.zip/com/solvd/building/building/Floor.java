package com.solvd.building.building;

import com.solvd.building.Interfaces.IFloor;

import java.util.Arrays;
import java.util.Scanner;
import java.util.logging.Logger;

public class Floor implements IFloor {

    public Floor(String[] args) throws Exception {
        Logger logger = Logger.getLogger(Floor.class.getName());
        String[] floors = new String[11];
        floors[0] = "lobby";
        floors[1] = "conference and meeting halls";
        floors[2] = "normal apartment floor 1";
        floors[3] = "normal apartments floor 2";
        floors[4] = "normal apartments floor 3";
        floors[5] = "normal apartments floor 4";
        floors[6] = "normal apartments floor 5";
        floors[7] = "luxury apartments floor 1";
        floors[8] = "luxury apartments floor 2";
        floors[9] = "luxury apartments floor 3";
        floors[10] = "penthouse floor";

        System.out.println("Elements in the array are: ");
        System.out.println(Arrays.toString(floors));
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the index of the required element :");
        try {
            int element = sc.nextInt();
            System.out.println("Element in the given index is : " + floors[element]);
        } catch (ArrayIndexOutOfBoundsException e) {
            logger.info("The index you have entered is invalid");
            logger.info("Please enter an index number between 0 and 10");
        }
    }
        private static Floor amount;
        private int floor = 10;

    public Floor() {
        }

    public static Floor getAmount() {
        return amount;
    }

    public static void setAmount(Floor amount) {
        Floor.amount = amount;
    }

    public void floor (int floor){
            this.floor = floor;
        }

        public int getFloor () {
            return floor;
        }

        public void setFloors ( int floor){
            this.floor = floor;
        }

        @Override
        public String toString () {
            return "Floors{" +
                    "floors=" + floor +
                    '}';
        }


        @Override
        public int hashCode () {
            return super.hashCode();
        }

        @Override
        public boolean equals (Object o){
            if (o == null) return false;
            if (o == this) return true;
            if (!(o instanceof Floor)) {
                return false;
            }
            Floor floor = (Floor) o;
            Floor Floor = new Floor();
            return floor == Floor.amount;
        }

        public void setFloor ( int i){
        }

    @Override
    public void overrideMethod(String str) {

    }
}


