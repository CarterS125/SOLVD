package com.solvd.building.building;

import com.solvd.building.Interfaces.IWall;

import java.util.Arrays;
import java.util.Scanner;
import java.util.logging.Logger;

public class Wall implements IWall {
    public Wall(String[] args) throws Exception{
        Logger logger = Logger.getLogger(Wall.class.getName());
        String[] wall = new String[4];
        wall[0] = "front of building";
        wall[1] = "left side of building";
        wall[2] = "right side of building";
        wall[3] = "back side of building";

        System.out.println("Elements in the array are: ");
        System.out.println(Arrays.toString(wall));
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the index of the required element :");
        try {
            int element = sc.nextInt();
            System.out.println("Element in the given index is :" + wall[element]);
        } catch (ArrayIndexOutOfBoundsException e) {
            logger.info("The index you have entered is invalid");
            logger.info("Please enter an index number between 0 and 10");
        }
    }

    private int wall = 4;
    private Object amount;

    public Wall(){}

    public void Wall(int wall) {
        this.wall = wall;
    }

    public int getWall() {
        return wall;
    }

    public void setWall(int wall) {
        this.wall = wall;
    }


    @Override
    public String toString() {
        return "Walls{" +
                "walls=" + wall +
                '}';
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public boolean equals(Object o) {
        if (o == null) return false;
        if (o == this) return true;
        if (!(o instanceof Wall)) {
            return false;
        }
        Wall wall = (Wall) o;
        return wall == wall.amount;
    }

    @Override
    public void overrideMethod(String str) {

    }
}
