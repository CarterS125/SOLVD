package com.solvd.building.building;

public class BuildingLocation {
    private String city;
    private String state;
    private String county;
    private String nearOcean;

public BuildingLocation(String city, String state, String county, String nearOcean) {
    this.city = city;
    this.state = state;
    this.county = county;
    this.nearOcean = nearOcean;
}

    public BuildingLocation() {

    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        state = state;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        county = county;
    }

    public String getNearOcean() {
        return nearOcean;
    }

    public void setNearOcean(String nearOcean) {
        nearOcean = nearOcean;
    }
}
