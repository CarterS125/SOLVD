package com.solvd.building.Materials;

import com.solvd.building.building.BuildingMaterial;

public class Metal extends BuildingMaterial {
    private String amount;
    private int price;
    private String type;
    private int weight;
    private String durability;

    public Metal () {}

    public Metal (String amount, int price, int weight, String durability, String type) {
        this.amount = amount;
        this.price = price;
        this.durability = durability;
        this.type = type;
        this.weight = weight;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public String getDurability() {
        return durability;
    }

    public void setDurability(String durability) {
        this.durability = durability;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
}
