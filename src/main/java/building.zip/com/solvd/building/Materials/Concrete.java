package com.solvd.building.Materials;

import com.solvd.building.building.BuildingMaterial;

public class Concrete extends BuildingMaterial {
    private String amount;
    private int price;
    private int weight;
    private String locationOfConcrete;
    private String strength;
    private String longivity;

    public Concrete () {}

    public Concrete (String amount, int price, int weight, String longivity, String locationOfConcrete, String strength) {
        this.amount = amount;
        this.price = price;
        this.longivity = longivity;
        this.locationOfConcrete = locationOfConcrete;
        this.strength = strength;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public String getLocationOfConcrete() {
        return locationOfConcrete;
    }

    public void setLocationOfConcrete(String locationOfConcrete) {
        this.locationOfConcrete = locationOfConcrete;
    }

    public String getStrength() {
        return strength;
    }

    public void setStrength(String strength) {
        this.strength = strength;
    }

    public String getLongivity() {
        return longivity;
    }

    public void setLongivity(String longivity) {
        this.longivity = longivity;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
}
