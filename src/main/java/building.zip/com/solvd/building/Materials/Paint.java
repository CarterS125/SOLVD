package com.solvd.building.Materials;

import com.solvd.building.building.BuildingMaterial;

public class Paint extends BuildingMaterial {
    private String amount;
    private int price;
    private String brandOfPaint;
    private int coatsNeeded;
    private String color;

    public Paint () {}

    public Paint (String amount, int price, String brandOfPaint, int coatsNeeded, String color) {
        this.amount = amount;
        this.price = price;
        this.color = color;
        this.brandOfPaint = brandOfPaint;
        this.coatsNeeded = coatsNeeded;
    }

    public String getBrandOfPaint() {
        return brandOfPaint;
    }

    public void setBrandOfPaint(String brandOfPaint) {
        this.brandOfPaint = brandOfPaint;
    }

    public int getCoatsNeeded() {
        return coatsNeeded;
    }

    public void setCoatsNeeded(int coatsNeeded) {
        this.coatsNeeded = coatsNeeded;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
}
