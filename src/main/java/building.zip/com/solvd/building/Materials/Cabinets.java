package com.solvd.building.Materials;

import com.solvd.building.BuildingTools.CabinetDrill;

public class Cabinets {
    private int amount;
    private String material;
    private String companyTheyCameFrom;
    private int price;

    public Cabinets() {}

    public Cabinets(int amount, int price, String material, String companyTheyCameFrom) {
        this.amount = amount;
        this.companyTheyCameFrom = companyTheyCameFrom;
        this.material = material;
        this.price = price;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public String getCompanyTheyCameFrom() {
        return companyTheyCameFrom;
    }

    public void setCompanyTheyCameFrom(String companyTheyCameFrom) {
        this.companyTheyCameFrom = companyTheyCameFrom;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
}
