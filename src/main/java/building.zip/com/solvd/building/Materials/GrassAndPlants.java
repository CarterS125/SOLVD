package com.solvd.building.Materials;

public class GrassAndPlants {
    private String plants;
    private String SOD;
    private int price;
    private int amountNeeded;

    public GrassAndPlants() {}

    private GrassAndPlants(String plants, String SOD, int price, int amountNeeded) {
        this.amountNeeded = amountNeeded;
        this.price = price;
        this.plants = plants;
        this.SOD = SOD;
    }

    public String getPlants() {
        return plants;
    }

    public void setPlants(String plants) {
        this.plants = plants;
    }

    public String getSOD() {
        return SOD;
    }

    public void setSOD(String SOD) {
        this.SOD = SOD;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getAmountNeeded() {
        return amountNeeded;
    }

    public void setAmountNeeded(int amountNeeded) {
        this.amountNeeded = amountNeeded;
    }
}
