package com.solvd.building.Materials;

import com.solvd.building.building.BuildingMaterial;

public class Tile extends BuildingMaterial {
    private String amount;
    private int price;
    private String style;
    private String madeOf;
    private String strength;

    public Tile () {}

    public Tile (String amount, int price, String strength, String madeOf, String style) {
        this.amount = amount;
        this.madeOf = madeOf;
        this.strength = strength;
        this.style = style;
        this.price = price;
    }

    public String getStyle() {
        return style;
    }

    public void setStyle(String style) {
        this.style = style;
    }

    public String getMadeOf() {
        return madeOf;
    }

    public void setMadeOf(String madeOf) {
        this.madeOf = madeOf;
    }

    public String getStrength() {
        return strength;
    }

    public void setStrength(String strength) {
        this.strength = strength;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
}
