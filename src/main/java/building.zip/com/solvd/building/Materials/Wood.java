package com.solvd.building.Materials;

import com.solvd.building.building.BuildingMaterial;

public class Wood extends BuildingMaterial {
    private String amount;
    private int price;
    private String type;
    private String longivity;
    private String howWellCanItHoldUpInElements;

    public Wood () {}

    public Wood (String amount, int price, String type, String longivity, String howWellCanItHoldUpInElements) {
        this.amount = amount;
        this.howWellCanItHoldUpInElements = howWellCanItHoldUpInElements;
        this.longivity = longivity;
        this.price = price;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getLongivity() {
        return longivity;
    }

    public void setLongivity(String longivity) {
        this.longivity = longivity;
    }

    public String getHowWellCanItHoldUpInElements() {
        return howWellCanItHoldUpInElements;
    }

    public void setHowWellCanItHoldUpInElements(String howWellCanItHoldUpInElements) {
        this.howWellCanItHoldUpInElements = howWellCanItHoldUpInElements;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
}
