package com.solvd.building.Materials;

import com.solvd.building.building.BuildingMaterial;

public class Drywall extends BuildingMaterial {
    private String amount;
    private int price;
    private int length;
    private int screwsNeededToSecure;
    private String durability;

    public Drywall () {}

    public Drywall (String amount, int price, String durability, int screwsNeededToSecure, int length) {
        this.amount = amount;
        this.screwsNeededToSecure = screwsNeededToSecure;
        this.durability = durability;
        this.length = length;
        this.price = price;
    }

    public int getScrewsNeededToSecure() {
        return screwsNeededToSecure;
    }

    public void setScrewsNeededToSecure(int screwsNeededToSecure) {
        this.screwsNeededToSecure = screwsNeededToSecure;
    }

    public String getDurability() {
        return durability;
    }

    public void setDurability(String durability) {
        this.durability = durability;
    }

    public int getLength() {
        return length;
    }

    public void setLength(int length) {
        this.length = length;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
}
