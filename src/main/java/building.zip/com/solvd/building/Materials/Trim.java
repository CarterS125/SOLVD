package com.solvd.building.Materials;

import com.solvd.building.building.BuildingMaterial;

public class Trim extends BuildingMaterial {
    private int amount;
    private int price;
    private String type;
    private int length;

    public Trim() {}

    public Trim(int amount, int price, int length, String type) {
        this.amount = amount;
        this.type = type;
        this.length = length;
        this.price = price;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getLength() {
        return length;
    }

    public void setLength(int length) {
        this.length = length;
    }
}
