package com.solvd.building.Materials;

import com.solvd.building.building.BuildingMaterial;

public class Piping extends BuildingMaterial {
    private String amount;
    private int price;
    private int lengthNeeded;
    private String madeOf;
    private String glueOrScrewTogether;

    public Piping () {}

    public Piping (String amount, int price, int lengthNeeded, String madeOf, String glueOrScrewTogether) {
        this.amount = amount;
        this.price = price;
        this.glueOrScrewTogether = glueOrScrewTogether;
        this.lengthNeeded = lengthNeeded;
        this.madeOf = madeOf;
    }

    public int getLengthNeeded() {
        return lengthNeeded;
    }

    public void setLengthNeeded(int lengthNeeded) {
        this.lengthNeeded = lengthNeeded;
    }

    public String getMadeOf() {
        return madeOf;
    }

    public void setMadeOf(String madeOf) {
        this.madeOf = madeOf;
    }

    public String getGlueOrScrewTogether() {
        return glueOrScrewTogether;
    }

    public void setGlueOrScrewTogether(String glueOrScrewTogether) {
        this.glueOrScrewTogether = glueOrScrewTogether;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
}
