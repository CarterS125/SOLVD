package com.solvd.building.Materials;

import com.solvd.building.building.BuildingMaterial;

public class Wiring extends BuildingMaterial {
    private String amount;
    private int price;
    private String wattage;
    private String capabilites;
    private int lengthNeeded;

    public Wiring () {}

    public Wiring (String amount, int price, String wattage, String capabilites, int lengthNeeded) {
        this.amount = amount;
        this.price = price;
        this.capabilites = capabilites;
        this.lengthNeeded = lengthNeeded;
        this.wattage = wattage;
    }

    public String getWattage() {
        return wattage;
    }

    public void setWattage(String wattage) {
        this.wattage = wattage;
    }

    public String getCapabilites() {
        return capabilites;
    }

    public void setCapabilites(String capabilites) {
        this.capabilites = capabilites;
    }

    public int getLengthNeeded() {
        return lengthNeeded;
    }

    public void setLengthNeeded(int lengthNeeded) {
        this.lengthNeeded = lengthNeeded;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
}
