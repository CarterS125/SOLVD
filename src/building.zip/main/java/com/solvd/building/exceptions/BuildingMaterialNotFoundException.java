package com.solvd.building.exceptions;

public class BuildingMaterialNotFoundException extends Exception {
    public BuildingMaterialNotFoundException(String message) {super(message);}
}
