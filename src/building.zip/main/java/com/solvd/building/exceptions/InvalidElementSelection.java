package com.solvd.building.exceptions;

public class InvalidElementSelection extends Exception {

    public InvalidElementSelection(String message) {super(message);}
}
