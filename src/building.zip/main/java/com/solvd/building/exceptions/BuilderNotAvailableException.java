package com.solvd.building.exceptions;

public class BuilderNotAvailableException extends Exception{
    public BuilderNotAvailableException(String message) {super(message);}
}
