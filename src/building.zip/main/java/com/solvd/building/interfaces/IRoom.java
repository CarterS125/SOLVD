package com.solvd.building.interfaces;

import com.solvd.building.elements.Room;

public interface IRoom {

    void buildRoom(Room r);

}
