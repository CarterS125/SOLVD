package com.solvd.building.building;

public class BuildingLocation {

    enum Location {
        CITY, STATE, COUNTY, NEAROCEAN;
    }
    public BuildingLocation() {

    }

    public String getCITY() {
         return "miami";
    }

    public void setCity(String city) {
        city = city;
    }

    public String getState() {
        return "Florida";
    }

    public void setState(String state) {
        state = state;
    }

    public String getCounty() {
        return "Miami Dade County";
    }

    public void setCounty(String county) {
        county = county;
    }

    public String getNearOcean() {
        return "is near ocean";
    }

    public void setNearOcean(String nearOcean) {
        nearOcean = nearOcean;
    }
}
