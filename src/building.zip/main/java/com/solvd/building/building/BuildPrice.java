package com.solvd.building.building;

public class BuildPrice {

    enum Price {
        PRICE, FINALPRICE;
    }

    public BuildPrice() {

    }

    public int getPrice() {
        return 50000000;
    }

    public int FinalPrice() {
        return 65000000;
    }

    public void setFinalPrice(int finalPrice) {
        finalPrice = finalPrice;
    }

    public void setPrice(int price) {
        price = price;
    }
}
