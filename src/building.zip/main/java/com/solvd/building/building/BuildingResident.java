package com.solvd.building.building;

public class BuildingResident {

    enum Resident {
        FNAME, LNAME, AGE, GENDER, OCCUPATION
    }

    public BuildingResident() {

    }

    public String getFName() {
        return "fName";
    }

    public String getLName() {
        return "lName";
    }

    public int getAge() {
        return 21;
    }

    public String getGender() {
        return "gender";
    }

    public String getOccupation() {
        return "occupation";
    }

}
