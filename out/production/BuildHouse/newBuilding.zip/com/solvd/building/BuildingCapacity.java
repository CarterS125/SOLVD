package com.solvd.building;

import java.security.DrbgParameters;

public class BuildingCapacity {
    private int capacity;
    public BuildingCapacity () {
        int Capacity = 200;
        this.capacity = Capacity;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        capacity = capacity;
    }
}
