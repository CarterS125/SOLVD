package com.solvd.building;

public class ConcreteGuys extends Builder{
    private String fName;
    private String lName;
    private String companyName;
    private int price;
}
