package com.solvd.building;

public class BuildingTools {
    private Excavator excavator;
    private Crane crane;
    private Bulldozer bulldozer;
    private ConcretePumps concretePumps;
    private GeneralTools generalTools;

    public BuildingTools(Excavator excavator, Crane crane, Bulldozer bulldozer, ConcretePumps concretePumps, GeneralTools generalTools) {
        this.excavator = excavator;
        this.crane = crane;
        this.bulldozer = bulldozer;
        this.concretePumps = concretePumps;
        this.generalTools = generalTools;
    }

    public BuildingTools() {
    }

    public Excavator getExcavator() {
        return excavator;
    }

    public void setExcavator() {
        this.excavator = excavator;
    }

    public Crane getCrane() {
        return crane;
    }

    public void setCrane() {
        this.crane = crane;
    }

    public Bulldozer getBulldozer() {
        return bulldozer;
    }

    public void setBulldozer() {
        this.bulldozer = bulldozer;
    }

    public ConcretePumps getConcretePumps() {
        return concretePumps;
    }

    public void setConcretePumps() {
        this.concretePumps = concretePumps;
    }

    public GeneralTools getGeneralTools() {
        return generalTools;
    }

    public void setGeneralTools() {
        this.generalTools = generalTools;
    }
}
