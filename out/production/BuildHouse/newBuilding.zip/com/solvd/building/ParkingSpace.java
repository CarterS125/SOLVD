package com.solvd.building;

public class ParkingSpace {
   private int parkingSpace = 200;

   public ParkingSpace(){}

    public void ParkingSpace(int parkingSpace) {
        this.parkingSpace = parkingSpace;
    }

    public int getParkingSpace() {
        return parkingSpace;
    }

    public void setParkingSpace(int parkingSpace) {
        this.parkingSpace = parkingSpace;
    }
}
