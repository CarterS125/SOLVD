package com.solvd.building;

public class Glass extends BuildingMaterial {
    private String amount;
    private int price;

    public Glass () {}

    public Glass (String amount, int price) {
        this.amount = amount;
        this.price = price;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
}
