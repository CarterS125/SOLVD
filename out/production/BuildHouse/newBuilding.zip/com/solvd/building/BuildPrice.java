package com.solvd.building;

public class BuildPrice {
    private int price;
    private int finalPrice;

    public BuildPrice(int price, int finalPrice) {
    }

    public BuildPrice() {

    }

    public void BuildPrice() {
        this.price = price;
        this.finalPrice = finalPrice;
    }

    public int getPrice() {
        return price;
    }

    public int FinalPrice() {
        return finalPrice;
    }

    public void setFinalPrice(int finalPrice) {
        finalPrice = finalPrice;
    }

    public void setPrice(int price) {
        price = price;
    }
}
