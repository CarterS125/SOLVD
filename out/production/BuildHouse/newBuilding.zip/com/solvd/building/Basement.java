package com.solvd.building;

public class Basement {
    private String basement = "Build a basement to incorporate a parking garage";

    public Basement(){}

    public void Basement(String basement) {
        this.basement = basement;
    }

    public String getBasement() {
        return basement;
    }

    public void setBasement(String basement) {
        this.basement = basement;
    }
}
