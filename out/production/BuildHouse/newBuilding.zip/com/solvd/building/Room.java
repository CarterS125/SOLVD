package com.solvd.building;

import java.util.Objects;

public class Room {
    private int room = 100;
    private Room amount;

    public Room(){}

    public void Room(int room) {
        this.room = room;
    }

    public int getRoom() {
        return room;
    }

    public void setAmount(Room amount) {
        this.amount = amount;
    }

    @Override
    public String toString() {
        return "Rooms{" +
                "rooms=" + room +
                '}';
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public boolean equals(Object o) {
        if (o == null) return false;
        if (o == this) return true;
        if (!(o instanceof Room)) {
            return false;
        }
        Room room = (Room) o;
        return room == room.amount;
    }

    public void setRoom(int i) {
    }
}
