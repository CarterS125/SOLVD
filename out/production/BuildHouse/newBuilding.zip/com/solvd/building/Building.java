package com.solvd.building;

public abstract class Building {
    private Wall wall;
    private Floor floor;
    private Room room;
    private Roof roof;
    private Basement basement;
    private ParkingSpace parkingSpace;

    public Building(){}

    public void Building(Wall wall, Room room, Floor floor, Roof roof, Basement basement, ParkingSpace parkingSpace) {
        this.basement = basement;
        this.roof = roof;
        this.room = room;
        this.floor = floor;
        this.wall = wall;
        this.parkingSpace = parkingSpace;
    }

    public int getWall() {
        return wall.getWall();
    }

    public void setWall(Wall wall) {
        this.wall = wall;
    }

    public Floor getFloors() {
        return floor;
    }

    public void setFloors(Floor floor) {
        this.floor = floor;
    }

    public Room getRooms() {
        return room;
    }

    public void setRooms(Room room) {
        this.room = room;
    }

    public Roof getRoof() {
        return roof;
    }

    public void setRoof(Roof roof) {
        this.roof = roof;
    }

    public Basement getBasement() {
        return basement;
    }

    public void setBasement(Basement basement) {
        this.basement = basement;
    }

    public ParkingSpace getParkingSpace() {
        return parkingSpace;
    }

    public void setParkingSpaces(ParkingSpace parkingSpace) {
        this.parkingSpace = parkingSpace;
    }

    public void setName(String palisades) {
    }

    public Building building(Building building) {
        return building;
    }


    public abstract int Hashcode();
}
