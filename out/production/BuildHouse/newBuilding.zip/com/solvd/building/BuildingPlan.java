package com.solvd.building;

public class BuildingPlan {
    private String architecture;
    private int squareFeet;
    private Room rooms;
    private String color;
    private com.solvd.building.Floor Floor;

    public void BuildingPlan(String architecture, int squareFeet, Room rooms, Floor floors, String color) {
        this.architecture = architecture;
        this.color = color;
        this.Floor = Floor;
        this.rooms = rooms;
        this.squareFeet = squareFeet;
    }

    public BuildingPlan(){}

    public String getArchitecture() {
        return architecture;
    }

    public void setArchitecture(String architecture) {
        architecture = architecture;
    }

    public int getSquareFeet() {
        return squareFeet;
    }

    public void setSquareFeet(int squareFeet) {
        squareFeet = squareFeet;
    }

    public Floor getFloor() {
        return Floor;
    }

    public void setFloors(Floor floor) {
        Floor = floor;
    }

    public Room getRoom() {
        return rooms;
    }

    public void setRooms(Room room) {
        rooms = rooms;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        color = color;
    }
}
