package com.solvd.building;

import java.util.Objects;

public class Floor {
    public static void main(String[] args) {
        String[] floors = new String[11];
        floors[0] = "lobby";
        floors[1] = "conference and meeting halls";
        floors[2] = "normal apartment floor 1";
        floors[3] = "normal apartments floor 2";
        floors[4] = "normal apartments floor 3";
        floors[5] = "normal apartments floor 4";
        floors[6] = "normal apartments floor 5";
        floors[7] = "luxury apartments floor 1";
        floors[8] = "luxury apartments floor 2";
        floors[9] = "luxury apartments floor 3";
        floors[10] = "penthouse floor";
    }
        private static Floor amount;
        private int floor = 10;

    public Floor() {
        }

    public static Floor getAmount() {
        return amount;
    }

    public static void setAmount(Floor amount) {
        Floor.amount = amount;
    }

    public void floor (int floor){
            this.floor = floor;
        }

        public int getFloor () {
            return floor;
        }

        public void setFloors ( int floor){
            this.floor = floor;
        }

        @Override
        public String toString () {
            return "Floors{" +
                    "floors=" + floor +
                    '}';
        }


        @Override
        public int hashCode () {
            return super.hashCode();
        }

        @Override
        public boolean equals (Object o){
            if (o == null) return false;
            if (o == this) return true;
            if (!(o instanceof Floor)) {
                return false;
            }
            Floor floor = (Floor) o;
            com.solvd.building.Floor Floor = new Floor();
            return floor == Floor.amount;
        }

        public void setFloor ( int i){
        }
    }


