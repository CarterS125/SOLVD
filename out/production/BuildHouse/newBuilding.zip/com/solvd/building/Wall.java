package com.solvd.building;

import java.util.Objects;

public class Wall {
    public static void main(String[] args) {
        String[] wall =  new String[4];
        wall[0] = "front of building";
        wall[1] = "left side of building";
        wall[2] = "right side of building";
        wall[3] = "back side of building";
    }
    private int wall = 4;
    private Object amount;

    public Wall(){}

    public void Wall(int wall) {
        this.wall = wall;
    }

    public int getWall() {
        return wall;
    }

    public void setWall(int wall) {
        this.wall = wall;
    }


    @Override
    public String toString() {
        return "Walls{" +
                "walls=" + wall +
                '}';
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public boolean equals(Object o) {
        if (o == null) return false;
        if (o == this) return true;
        if (!(o instanceof Wall)) {
            return false;
        }
        Wall wall = (Wall) o;
        return wall == wall.amount;
    }
}
