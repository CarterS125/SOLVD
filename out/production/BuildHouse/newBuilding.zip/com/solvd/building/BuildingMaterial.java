package com.solvd.building;

public class BuildingMaterial {
    private Concrete concrete;
    private Wood wood;
    private Wiring wiring;
    private Piping piping;
    private Glass glass;
    private Drywall drywall;
    private Paint paint;
    private Tile tile;
    private Metal metal;

    public BuildingMaterial(Concrete concrete, Wood Wood, Wiring Wiring, Piping piping, Glass Glass, Drywall Drywall, Paint Paint, Tile Tile, Metal Metal) {
        this.concrete = concrete;
        this.glass = Glass;
        this.wood = Wood;
        this.wiring = Wiring;
        this.paint = Paint;
        this.drywall = Drywall;
        this.tile = Tile;
        this.metal = Metal;
        this.piping = piping;
    }

    public BuildingMaterial() {

    }
    public static void setMaterials() {
    }

    public Concrete getConcrete() {
        return concrete;
    }

    public void setConcrete() {
        this.concrete = concrete;
    }

    public Wood getWood() {
        return wood;
    }

    public void setWood() {
        this.wood = wood;
    }

    public Wiring getWiring() {
        return wiring;
    }

    public void setWiring() {
        this.wiring = wiring;
    }

    public Piping getPiping() {
        return piping;
    }

    public void setPiping() {
        this.piping = piping;
    }

    public Glass getGlass() {
        return glass;
    }

    public void setGlass() {
        this.glass = glass;
    }

    public Drywall getDrywall() {
        return drywall;
    }

    public void setDrywall() {
        this.drywall = drywall;
    }

    public Paint getPaint() {
        return paint;
    }

    public void setPaint() {
        this.paint = paint;
    }

    public Tile getTile() {
        return tile;
    }

    public void setTile() {
        this.tile = tile;
    }

    public Metal getMetal() {
        return metal;
    }

    public void setMetal() {
        this.metal = metal;
    }
}
