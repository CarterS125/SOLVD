package com.solvd.building;

public class GeneralTools extends BuildingTools {
    private String make;
    private String model;
    private String company;
    private int price;

    public GeneralTools () {}

    public GeneralTools (String model, String make, String company, int price) {
        this.company = company;
        this.price = price;
        this.make = make;
        this.model = model;
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
}
