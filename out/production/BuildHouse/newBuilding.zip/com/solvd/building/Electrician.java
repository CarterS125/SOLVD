package com.solvd.building;

public class Electrician extends Builder{
    private String fName;
    private String lName;
    private String companyName;
    private int price;

    public Electrician () {}

    public Electrician (String fName, String lName, String companyName, int price) {
        this.companyName = companyName;
        this.fName = fName;
        this.lName = lName;
        this.price = price;
    }

    public String getfName() {
        return fName;
    }

    public void setfName(String fName) {
        this.fName = fName;
    }

    public String getlName() {
        return lName;
    }

    public void setlName(String lName) {
        this.lName = lName;
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
}
