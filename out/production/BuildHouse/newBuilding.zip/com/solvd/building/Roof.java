package com.solvd.building;

public class Roof {
    private String roof = "Build a roof that is modern in style but prevents damage";

    public Roof(){}

    public void Roof(String roof) {
        this.roof = roof;
    }

    public String getRoof() {
        return roof;
    }

    public void setRoof(String roof) {
        this.roof = roof;
    }
}
