package com.solvd.building;

public class Builder {
    private static Plumbers plumbers;
    private static ConcreteGuys concreteGuys;
    private static Electrician electrician;
    private static DryWaller dryWaller;
    private static Landscapers landscapers;
    private static CabinetGuys cabinetGuys;
    private static TrimGuys trimGuys;
    private static Painter painters;

    public Builder(){}

    public void Builder(Painter painters, Plumbers plumbers, Landscapers landscapers, Electrician electrician, TrimGuys trimGuys, CabinetGuys cabinetGuys, ConcreteGuys concreteGuys, DryWaller dryWaller, Painter painter) {
        this.plumbers = plumbers;
        this.electrician = electrician;
        this.concreteGuys = concreteGuys;
        this.trimGuys = trimGuys;
        this.dryWaller = dryWaller;
        this.cabinetGuys = cabinetGuys;
        this.landscapers = landscapers;
        this.painters = painters;
    }

    public static Plumbers getPlumbers() {
        return plumbers;
    }

    public static void setPlumbers() {
        Builder.plumbers = plumbers;
    }

    public static ConcreteGuys getConcreteGuys() {
        return concreteGuys;
    }

    public static void setConcreteGuys() {
        Builder.concreteGuys = concreteGuys;
    }

    public static Electrician getElectrician() {
        return electrician;
    }

    public static void setElectrician() {
        Builder.electrician = electrician;
    }

    public static DryWaller getDryWaller() {
        return dryWaller;
    }

    public static void setDryWaller() {
        Builder.dryWaller = dryWaller;
    }

    public static Landscapers getLandscapers() {
        return landscapers;
    }

    public static void setLandscapers() {
        Builder.landscapers = landscapers;
    }

    public static CabinetGuys getCabinetGuys() {
        return cabinetGuys;
    }

    public static void setCabinetGuys() {
        Builder.cabinetGuys = cabinetGuys;
    }

    public static TrimGuys getTrimGuys() {
        return trimGuys;
    }

    public static void setTrimGuys() {
        Builder.trimGuys = trimGuys;
    }

    public static Painter getPainters() {
        return painters;
    }

    public static void setPainters() {
        Builder.painters = painters;
    }
}
