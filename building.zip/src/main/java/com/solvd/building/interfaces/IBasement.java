package com.solvd.building.interfaces;

import com.solvd.building.elements.Basement;

public interface IBasement {

    void buildBasement(Basement b);
}


