package com.solvd.building.interfaces;

import com.solvd.building.elements.Roof;

public interface IRoof {

    void buildRoof(Roof r);

}
