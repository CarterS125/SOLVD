package com.solvd.building.interfaces;

import com.solvd.building.elements.Wall;

public interface IWall {

    void buildWall(Wall w);

}
