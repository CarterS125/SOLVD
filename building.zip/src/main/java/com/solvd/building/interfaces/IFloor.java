package com.solvd.building.interfaces;

import com.solvd.building.elements.Floor;

public interface IFloor {

    void buildFloor(Floor f);
}

