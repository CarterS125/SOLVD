package com.solvd.building.LambdaInterfaces;

import java.util.HashMap;

@FunctionalInterface
public interface IElement {
    void message(HashMap element);
}
