package com.solvd.building.LambdaInterfaces;

import java.util.ArrayList;

@FunctionalInterface
public interface IBuilderList {
    void message(ArrayList builder);
}
