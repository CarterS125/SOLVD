package com.solvd.building.exceptions;

public class InvalidToolSelection extends Exception {

    public InvalidToolSelection(String message) {super(message);}
}
