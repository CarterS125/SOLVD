package com.solvd.building.exceptions;

public class InvalidBuildingStaffSelection extends Exception {

    public InvalidBuildingStaffSelection(String message) {super(message);}
}
