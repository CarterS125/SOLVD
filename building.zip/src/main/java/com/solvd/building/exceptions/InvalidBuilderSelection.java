package com.solvd.building.exceptions;

public class InvalidBuilderSelection extends Exception {

    public InvalidBuilderSelection(String message) {super(message);}
}
