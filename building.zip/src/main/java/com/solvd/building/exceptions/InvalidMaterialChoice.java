package com.solvd.building.exceptions;

public class InvalidMaterialChoice extends Exception {

    public InvalidMaterialChoice(String message) {super(message);}
}
