package com.solvd.building.building;

public class BuildingResident {

    enum Resident {
        FNAME, LNAME, AGE, GENDER, OCCUPATION
    }

    public BuildingResident() {

    }

    public String getFNAME() {
        return "residents first name";
    }

    public String getLNAME() {
        return "residents last name";
    }

    public int getAGE() {
        return 21;
    }

    public String getGENDER() {
        return "gender of resident";
    }

    public String getOCCUPATION() {
        return "occupation of resident";
    }


}
