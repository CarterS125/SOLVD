package com.solvd.building.building;

public class BuildPrice {

    enum Price {
        PRICE, FINALPRICE;
    }

    public BuildPrice() {

    }

    public int getPRICE() {
        return 50000000;
    }

    public int getFINALPRICE() {
        return 65000000;
    }
}
