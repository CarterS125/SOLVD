package com.solvd.building.building;

public class BuildingLocation {

    enum Location {
        CITY, STATE, COUNTY, NEAROCEAN;
    }
    public BuildingLocation() {

    }

    public String getCITY() {
         return "miami";
    }

    public String getSTATE() {
        return "Florida";
    }

    public String getCOUNTY() {
        return "Miami Dade County";
    }

    public String getNEAROCEAN() {
        return "is near ocean";
    }

}
